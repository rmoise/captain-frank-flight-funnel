"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/searchFlights.ts
var searchFlights_exports = {};
__export(searchFlights_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(searchFlights_exports);
var API_BASE_URL = "https://secure.captain-frank.net/api/services/euflightclaim";
var handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      body: "Method Not Allowed"
    };
  }
  const { from_iata, to_iata, date, flight_number } = event.queryStringParameters || {};
  console.log("Search parameters:", {
    from_iata,
    to_iata,
    date,
    flight_number
  });
  if (!from_iata || !to_iata || !date) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: "Missing required parameters",
        required: ["from_iata", "to_iata", "date"],
        received: event.queryStringParameters
      })
    };
  }
  try {
    let apiUrl = `${API_BASE_URL}/searchflightsbyfromiatatoiatadatenumber?from_iata=${from_iata}&to_iata=${to_iata}&flight_date=${date}&lang=en`;
    if (flight_number) {
      apiUrl += `&flight_number=${flight_number}`;
    }
    console.log("Making request to:", apiUrl);
    const response = await fetch(apiUrl, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    });
    console.log("Response status:", response.status);
    const responseText = await response.text();
    console.log("Raw API response:", responseText);
    if (!response.ok) {
      console.error("API error:", {
        status: response.status,
        statusText: response.statusText,
        body: responseText
      });
      return {
        statusCode: response.status,
        body: JSON.stringify({
          error: `API Error: ${response.status} ${response.statusText}`,
          details: responseText
        })
      };
    }
    let result;
    try {
      result = JSON.parse(responseText);
      console.log("Parsed response:", JSON.stringify(result, null, 2));
    } catch (parseError) {
      console.error("Failed to parse API response:", parseError);
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Invalid JSON response from API",
          details: responseText
        })
      };
    }
    const flights = Array.isArray(result.data) ? result.data : [];
    if (flights.length === 0) {
      console.log("No flights found for the given criteria");
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          data: [],
          message: "No flights found for the given criteria. This could be because the route is not available, the date is outside the searchable range, or there are no scheduled flights for this route on the specified date.",
          searchParams: {
            from_iata,
            to_iata,
            date,
            flight_number
          }
        })
      };
    }
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        data: flights,
        message: "Flights found successfully"
      })
    };
  } catch (error) {
    console.error("Error searching flights:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        message: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
