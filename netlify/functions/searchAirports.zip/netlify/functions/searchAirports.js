"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/searchAirports.ts
var searchAirports_exports = {};
__export(searchAirports_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(searchAirports_exports);
var API_BASE_URL = "https://secure.captain-frank.net/api/services/euflightclaim";
var handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      body: "Method Not Allowed"
    };
  }
  const { term, lang } = event.queryStringParameters || {};
  if (!term) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Search term is required" })
    };
  }
  try {
    const apiUrl = `${API_BASE_URL}/searchairportsbyterm?term=${encodeURIComponent(term)}${lang ? `&lang=${lang}` : ""}`;
    console.log("Making request to:", apiUrl);
    const response = await fetch(apiUrl, {
      headers: {
        Accept: "application/json"
      }
    });
    console.log("Response status:", response.status);
    const responseText = await response.text();
    console.log("Raw API response:", responseText);
    if (!response.ok) {
      console.error("API error:", {
        status: response.status,
        statusText: response.statusText,
        body: responseText
      });
      return {
        statusCode: response.status,
        body: JSON.stringify({
          error: `API Error: ${response.status} ${response.statusText}`,
          details: responseText
        })
      };
    }
    let result;
    try {
      result = JSON.parse(responseText);
      console.log("Parsed response:", JSON.stringify(result, null, 2));
    } catch (parseError) {
      console.error("Failed to parse API response:", parseError);
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Invalid JSON response from API",
          details: responseText
        })
      };
    }
    const airports = Array.isArray(result.data) ? result.data : [];
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(airports)
    };
  } catch (error) {
    console.error("Error searching airports:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        message: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
