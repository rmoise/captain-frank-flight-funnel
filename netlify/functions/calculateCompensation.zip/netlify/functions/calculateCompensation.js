"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/calculateCompensation.ts
var calculateCompensation_exports = {};
__export(calculateCompensation_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(calculateCompensation_exports);
var API_BASE_URL = "https://secure.captain-frank.net/api/services/euflightclaim";
var handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      body: "Method Not Allowed"
    };
  }
  const { from_iata, to_iata } = event.queryStringParameters || {};
  if (!from_iata || !to_iata) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing required parameters" })
    };
  }
  try {
    const apiUrl = `${API_BASE_URL}/calculatecompensationbyfromiatatoiata?from_iata=${from_iata}&to_iata=${to_iata}`;
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`API responded with status ${response.status}`);
    }
    const result = await response.json();
    if (typeof result.data !== "number") {
      throw new Error("Invalid response format: data is not a number");
    }
    const amount = result.data || 0;
    const compensationResult = {
      amount,
      currency: "EUR"
    };
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(compensationResult)
    };
  } catch (error) {
    console.error("Error calculating compensation:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal Server Error" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
