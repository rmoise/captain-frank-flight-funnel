"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/ordereuflightclaim.ts
var ordereuflightclaim_exports = {};
__export(ordereuflightclaim_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ordereuflightclaim_exports);
var API_BASE_URL = "https://secure.captain-frank.net/api/services/euflightclaim";
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: "Method Not Allowed"
    };
  }
  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Request body is required" })
    };
  }
  try {
    const requestBody = JSON.parse(event.body);
    console.log("Received request body:", requestBody);
    const requiredFields = [
      "journey_booked_flightids",
      "journey_fact_flightids",
      "information_received_at",
      "journey_booked_pnr",
      "journey_fact_type",
      "owner_salutation",
      "owner_firstname",
      "owner_lastname",
      "owner_street",
      "owner_place",
      "owner_city",
      "owner_country",
      "owner_email",
      "owner_marketable_status",
      "contract_signature",
      "contract_tac",
      "contract_dp"
    ];
    const missingFields = requiredFields.filter((field) => !requestBody[field]);
    if (missingFields.length > 0) {
      console.error("Missing required fields:", missingFields);
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: `Missing required fields: ${missingFields.join(", ")}`,
          status: "error"
        })
      };
    }
    const validJourneyFactTypes = [
      "none",
      "self",
      "provided",
      "took_alternative_own"
    ];
    if (!validJourneyFactTypes.includes(requestBody.journey_fact_type)) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: `Invalid journey_fact_type: ${requestBody.journey_fact_type}. Valid values are: ${validJourneyFactTypes.join(", ")}`,
          valid_values: validJourneyFactTypes,
          status: "error"
        })
      };
    }
    if (!["herr", "frau"].includes(requestBody.owner_salutation)) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: "Invalid owner_salutation",
          valid_values: ["herr", "frau"],
          status: "error"
        })
      };
    }
    const journey_booked_flightids = requestBody.journey_booked_flightids.map(Number);
    const journey_fact_flightids = requestBody.journey_fact_flightids.map(Number);
    const owner_country = requestBody.owner_country.toUpperCase();
    const apiUrl = `${API_BASE_URL}/ordereuflightclaim`;
    console.log("Making request to:", apiUrl);
    const apiRequestBody = {
      ...requestBody,
      journey_booked_flightids,
      journey_fact_flightids,
      owner_country,
      owner_marketable_status: Boolean(requestBody.owner_marketable_status),
      contract_tac: Boolean(requestBody.contract_tac),
      contract_dp: Boolean(requestBody.contract_dp),
      lang: "en"
    };
    console.log("API request body:", apiRequestBody);
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify(apiRequestBody)
    });
    const responseText = await response.text();
    console.log("API Response:", responseText);
    if (!response.ok) {
      let errorMessage = `API responded with status ${response.status}`;
      try {
        const errorData = JSON.parse(responseText);
        errorMessage = errorData.message || errorData.error || errorMessage;
      } catch (e) {
        console.error("Failed to parse error response:", e);
      }
      throw new Error(errorMessage);
    }
    let result;
    try {
      result = JSON.parse(responseText);
    } catch (e) {
      console.error("Failed to parse success response:", e);
      throw new Error("Invalid response format from API");
    }
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error("Error ordering EU flight claim:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: error instanceof Error ? error.message : "Internal Server Error",
        details: error instanceof Error ? error.stack : void 0
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
